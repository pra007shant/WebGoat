CURTAG=webgoat/webgoat-8.0
DEST_TAG=gcr.io/your-gke-project/your-webgoat-tag
CLUSTER_NAME=your-cluster-name
PORT_NUM=8080